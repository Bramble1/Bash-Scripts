#!/bin/bash

sudo make install
sudo mv dwm /usr/bin
